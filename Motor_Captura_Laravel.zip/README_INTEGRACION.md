# Motor de Captura — Integración en el proyecto Laravel existente

Este paquete contiene el código del Motor de Captura diseñado en el
documento "Diseño de Flujo del Motor de Captura". Cópialo dentro de tu
proyecto Laravel manteniendo la misma estructura de carpetas
(`app/Models`, `app/Services/Captura`, `app/Console/Commands`).

## 1. Prerrequisito bloqueante: driver de SQL Server para PHP

Laravel necesita la extensión `sqlsrv` / `pdo_sqlsrv` de Microsoft
instalada en el servidor PHP para conectarse a `SOLUFLEX_FARO` y a la
base intermedia de Bizlinks (ambas SQL Server). **Sin esto, el Motor de
Captura no puede conectarse a ninguna tienda.** Confirmar con el equipo
de infraestructura antes de probar.

```bash
php -m | grep sqlsrv
```

## 2. Conexión a la base central (PostgreSQL)

Agrega la conexión `central` en `config/database.php` (los modelos
`Fe*` ya apuntan a `protected $connection = 'central';`):

```php
'central' => [
    'driver' => 'pgsql',
    'host' => env('CENTRAL_DB_HOST', '127.0.0.1'),
    'port' => env('CENTRAL_DB_PORT', '5432'),
    'database' => env('CENTRAL_DB_DATABASE', 'fe_control'),
    'username' => env('CENTRAL_DB_USERNAME', 'postgres'),
    'password' => env('CENTRAL_DB_PASSWORD', ''),
    'charset' => 'utf8',
    'prefix' => '',
    'schema' => 'public',
    'sslmode' => 'prefer',
],
```

Y en `.env`:

```
CENTRAL_DB_HOST=127.0.0.1
CENTRAL_DB_PORT=5432
CENTRAL_DB_DATABASE=fe_control
CENTRAL_DB_USERNAME=postgres
CENTRAL_DB_PASSWORD=
CAPTURA_CORREO_ALERTAS=soporte@tuempresa.com
```

## 3. Ajuste pendiente en FE_TIENDAS.password_conexion_cifrado

El esquema SQL original define esta columna como `BYTEA` (binario). El
código usa `Crypt::encryptString()` / `Crypt::decryptString()` de
Laravel, que ya devuelven un string cifrado en Base64 — no un binario
crudo. Para evitar problemas de codificación entre PHP y PostgreSQL,
se recomienda cambiar el tipo de columna a `TEXT`:

```sql
ALTER TABLE FE_TIENDAS
    ALTER COLUMN password_conexion_cifrado TYPE TEXT;
```

Al registrar una tienda desde el backend, la contraseña se guarda así:

```php
FeTienda::create([
    // ...
    'password_conexion_cifrado' => Crypt::encryptString('la-contraseña-real'),
]);
```

## 4. Registrar el comando en el scheduler

Este paquete incluye `routes/console.php` asumiendo Laravel 11+. Si el
proyecto usa Laravel 10 o anterior, mueve el bloque `Schedule::command(...)`
al método `schedule()` de `app/Console/Kernel.php`.

Confirmar que el cron del servidor tiene registrado:

```
* * * * * cd /ruta-al-proyecto && php artisan schedule:run >> /dev/null 2>&1
```

## 5. Probar manualmente antes de dejarlo en el scheduler

```bash
php artisan captura:ejecutar
```

Antes de la primera corrida real, registra la tienda de prueba en
`FE_TIENDAS` (ajustar valores reales):

```php
FeTienda::create([
    'codigo_tienda' => 'AQP01',
    'nombre_tienda' => 'MCH MP AREQUIPA',
    'idempresa_soluflex' => 1,
    'idsucursal_soluflex' => 172,
    'servidor_host' => '10.20.0.15',
    'servidor_puerto' => 1433,
    'bd_soluflex_nombre' => 'SOLUFLEX_FARO',
    'bd_bizlinks_nombre' => 'BIZLINKS_TST21',
    'usuario_conexion' => '...',
    'password_conexion_cifrado' => \Illuminate\Support\Facades\Crypt::encryptString('...'),
    'estado' => 'ACTIVA',
]);
```

## 6. Pendientes de negocio antes de ir a certificación con SUNAT

Ver el documento "Mapeo de Campos - Soluflex a Bizlinks" (sección 7).
Están marcados con comentarios `// TODO` o notas explícitas en
`TransformadorDocumentoService` y `ValidadorCapturaService`:

- Pago mixto (más de una forma de pago por venta) — no implementado.
- Tratamiento de la línea de cargo por bolsa (ICBPER) en el detalle —
  hoy se envía tal cual viene de Soluflex, sin conciliar contra el
  campo `totalMontoICBPER` de cabecera.

## 7. Antes de confiar el nombre real de columnas de Bizlinks

`InsercionBizlinksService` asume que los nombres de columna de
`SPE_EINVOICEHEADER` / `SPE_EINVOICEDETAIL` coinciden con las claves
usadas en `TransformadorDocumentoService`. Confirmar contra el DDL real
de esas tablas en `BIZLINKS_TST21` antes de la primera prueba de
inserción, y ajustar los nombres si difieren.
