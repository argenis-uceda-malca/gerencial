<?php

namespace App\Services\Captura;

use App\Models\FeTienda;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;

/**
 * Arma conexiones dinámicas hacia SOLUFLEX_FARO y la base intermedia de
 * Bizlinks de una tienda específica. Las tiendas no están fijas en
 * config/database.php porque viven en FE_TIENDAS y pueden crecer sin
 * necesidad de desplegar código (ver Plan de Acción, sección 4).
 *
 * Requiere la extensión sqlsrv / pdo_sqlsrv de Microsoft instalada en
 * el servidor PHP (ver README de este paquete).
 */
class ConexionTiendaService
{
    public function conexionSoluflex(FeTienda $tienda): ConnectionInterface
    {
        return $this->registrarYObtener($tienda, $tienda->bd_soluflex_nombre, 'soluflex');
    }

    public function conexionBizlinks(FeTienda $tienda): ConnectionInterface
    {
        return $this->registrarYObtener($tienda, $tienda->bd_bizlinks_nombre, 'bizlinks');
    }

    private function registrarYObtener(FeTienda $tienda, string $nombreBaseDatos, string $sufijo): ConnectionInterface
    {
        $nombreConexion = $this->nombreConexion($tienda, $sufijo);

        Config::set("database.connections.{$nombreConexion}", [
            'driver' => 'sqlsrv',
            'host' => $tienda->servidor_host,
            'port' => $tienda->servidor_puerto,
            'database' => $nombreBaseDatos,
            'username' => $tienda->usuario_conexion,
            'password' => Crypt::decryptString($tienda->password_conexion_cifrado),
            'charset' => 'utf8',
            'prefix' => '',
            'trust_server_certificate' => true,
            // Habilitar encrypt=>true en producción una vez confirmado
            // con el equipo de Redes/Infraestructura (ver Plan de Acción,
            // sección 4.3 - recomendaciones de seguridad).
        ]);

        return DB::connection($nombreConexion);
    }

    /**
     * Cierra y descarta la conexión al terminar de procesar la tienda,
     * para no acumular conexiones abiertas al recorrer muchas tiendas
     * en la misma ejecución del comando.
     */
    public function cerrar(FeTienda $tienda, string $sufijo): void
    {
        DB::purge($this->nombreConexion($tienda, $sufijo));
    }

    private function nombreConexion(FeTienda $tienda, string $sufijo): string
    {
        return "tienda_{$tienda->codigo_tienda}_{$sufijo}";
    }
}
