<?php

namespace App\Services\Captura;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Collection;

/**
 * Consulta las ventas candidatas a captura en SOLUFLEX_FARO: cerradas
 * (CODIGO_ESTADO = '12', confirmado contra M_ESTADOS), de un tipo de
 * documento marcado como electrónico, con la serie específica habilitada
 * para electrónico, y posteriores al cursor de la tienda.
 */
class DetectorVentasService
{
    public function obtenerVentasNuevas(ConnectionInterface $conexion, int $ultimoIdCapturado): Collection
    {
        return collect($conexion->select("
            SELECT c.*
            FROM CABECERA_DOCUMENTO c
            INNER JOIN DOCUMENTOS d
                ON d.CODIGO_DOCUMENTO = c.CODIGO_DOCUMENTO
            INNER JOIN DOCUMENTOS_SERIES ds
                ON ds.CODIGO_DOCUMENTO = c.CODIGO_DOCUMENTO
               AND ds.IDEMPRESA = c.IDEMPRESA
               AND ds.NUMERO_SERIE = c.NUMERO_SERIE
            WHERE c.IDTRANSACCION > ?
              AND c.CODIGO_ESTADO = '12'
              AND d.FLAG_FACT_ELECTRONICA = 'S'
              AND ds.FLAG_ELECTRONICO = 'S'
            ORDER BY c.IDTRANSACCION ASC
        ", [$ultimoIdCapturado]));
    }

    public function obtenerDetalle(ConnectionInterface $conexion, int $idTransaccion): Collection
    {
        return collect($conexion->select('
            SELECT *
            FROM DETALLE_DOCUMENTO
            WHERE IDTRANSACCION = ?
            ORDER BY SECUENCIA ASC
        ', [$idTransaccion]));
    }
}
