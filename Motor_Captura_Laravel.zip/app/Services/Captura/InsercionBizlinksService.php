<?php

namespace App\Services\Captura;

use Illuminate\Database\ConnectionInterface;

/**
 * Inserta el documento ya transformado y validado en las tablas de la
 * base intermedia de Bizlinks (SPE_EINVOICEHEADER / SPE_EINVOICEDETAIL).
 *
 * IMPORTANTE: los nombres de columna usados aquí asumen que coinciden
 * 1 a 1 con las claves devueltas por TransformadorDocumentoService
 * (que a su vez siguen el documento de mapeo de campos). Antes de
 * pasar a un ambiente real, confirmar el DDL exacto de estas dos
 * tablas en BIZLINKS_TST21 y ajustar aquí si algún nombre difiere.
 */
class InsercionBizlinksService
{
    public function insertar(ConnectionInterface $conexion, array $documento): void
    {
        $conexion->transaction(function () use ($conexion, $documento) {
            $this->insertarCabecera($conexion, $documento['cabecera']);

            foreach ($documento['detalle'] as $item) {
                $this->insertarDetalleItem($conexion, $item);
            }
        });
    }

    private function insertarCabecera(ConnectionInterface $conexion, array $cabecera): void
    {
        // bl_estadoRegistro='A' ya viene incluido en $cabecera (fijado
        // por TransformadorDocumentoService): es la señal que el
        // componente integrador de Bizlinks usa para tomar el documento.
        $conexion->table('SPE_EINVOICEHEADER')->insert($cabecera);
    }

    private function insertarDetalleItem(ConnectionInterface $conexion, array $item): void
    {
        // 'importeTotalItem' es de uso interno (validación de totales
        // en ValidadorCapturaService), no es columna real de la tabla.
        unset($item['importeTotalItem']);

        $conexion->table('SPE_EINVOICEDETAIL')->insert($item);
    }
}
