<?php

namespace App\Services\Captura;

use App\Models\FeControlRegistro;
use App\Models\FeLogSistema;
use App\Models\FeTienda;
use Illuminate\Database\ConnectionInterface;
use Throwable;

/**
 * Orquesta la captura completa de una tienda: detecta ventas nuevas,
 * las transforma, valida, e inserta en Bizlinks. Ver Diseño de Flujo
 * del Motor de Captura para el algoritmo completo documentado.
 */
class MotorCapturaService
{
    public function __construct(
        private ConexionTiendaService $conexiones,
        private DetectorVentasService $detector,
        private TransformadorDocumentoService $transformador,
        private ValidadorCapturaService $validador,
        private InsercionBizlinksService $insercion,
    ) {
    }

    /**
     * Procesa todas las ventas nuevas de una tienda. Aísla cualquier
     * excepción para que un fallo en una tienda no afecte a las demás.
     *
     * @return array{capturados: int, cuarentena: int, errores: int}
     */
    public function procesarTienda(FeTienda $tienda): array
    {
        $resumen = ['capturados' => 0, 'cuarentena' => 0, 'errores' => 0];

        try {
            $conexionSoluflex = $this->conexiones->conexionSoluflex($tienda);
            $ventas = $this->detector->obtenerVentasNuevas($conexionSoluflex, $tienda->ultimo_idtransaccion_capturado);

            foreach ($ventas as $venta) {
                $this->procesarVenta($tienda, $conexionSoluflex, $venta, $resumen);

                // El cursor avanza venta por venta, no al final del lote,
                // para no reprocesar ventas ya resueltas si el proceso
                // se interrumpe a mitad de camino (ver sección 5 del
                // Diseño de Flujo).
                $tienda->ultimo_idtransaccion_capturado = (int) $venta->IDTRANSACCION;
                $tienda->save();
            }

            $tienda->fecha_ultima_captura = now();
            $tienda->save();

            FeLogSistema::log(
                'INFO',
                'MOTOR_CAPTURA',
                "Tienda {$tienda->codigo_tienda}: capturados={$resumen['capturados']}, cuarentena={$resumen['cuarentena']}, errores={$resumen['errores']}",
                $tienda->codigo_tienda
            );
        } catch (Throwable $e) {
            FeLogSistema::log(
                'ERROR',
                'MOTOR_CAPTURA',
                "Fallo procesando tienda {$tienda->codigo_tienda}: {$e->getMessage()}",
                $tienda->codigo_tienda
            );
            // No se relanza: el comando debe seguir con la siguiente tienda.
        } finally {
            $this->conexiones->cerrar($tienda, 'soluflex');
            $this->conexiones->cerrar($tienda, 'bizlinks');
        }

        return $resumen;
    }

    private function procesarVenta(FeTienda $tienda, ConnectionInterface $conexionSoluflex, object $venta, array &$resumen): void
    {
        // La reserva del registro ocurre ANTES de tocar Bizlinks. La
        // restricción UNIQUE (codigo_tienda, idtransaccion_soluflex) es
        // la que garantiza que esta venta nunca se procese dos veces,
        // incluso si el proceso se interrumpe a mitad de camino.
        $registro = FeControlRegistro::firstOrCreate(
            [
                'codigo_tienda' => $tienda->codigo_tienda,
                'idtransaccion_soluflex' => $venta->IDTRANSACCION,
            ],
            [
                'estado' => 'PENDIENTE',
                'fecha_venta' => $venta->FECHA_DOCUMENTO,
                'importe_total' => $venta->IMPORTE_TOTAL,
            ]
        );

        // Si ya fue procesada (en esta corrida o en una anterior), no
        // se reprocesa.
        if (! in_array($registro->estado, ['PENDIENTE', 'ERROR_CAPTURA'], true)) {
            return;
        }

        $detalle = $this->detector->obtenerDetalle($conexionSoluflex, (int) $venta->IDTRANSACCION);
        $documento = $this->transformador->transformar($conexionSoluflex, $tienda, $venta, $detalle);
        $errores = $this->validador->validar($documento);

        if (! empty($errores)) {
            $continuar = $this->validador->resolver($registro, $documento, $errores);
            if (! $continuar) {
                $resumen['cuarentena']++;

                return;
            }
        }

        try {
            $this->insertarYConfirmar($tienda, $registro, $documento);
            $resumen['capturados']++;
        } catch (Throwable $e) {
            $this->marcarErrorCaptura($registro, $e->getMessage());
            $resumen['errores']++;
        }
    }

    private function insertarYConfirmar(FeTienda $tienda, FeControlRegistro $registro, array $documento): void
    {
        $conexionBizlinks = $this->conexiones->conexionBizlinks($tienda);
        $this->insercion->insertar($conexionBizlinks, $documento);

        $estadoAnterior = $registro->estado;
        $registro->fill([
            'estado' => 'CAPTURADO',
            'serie_numero_bizlinks' => $documento['cabecera']['serieNumero'],
            'tipo_documento_sunat' => $documento['cabecera']['tipoDocumento'],
            'numero_documento_emisor' => $documento['cabecera']['numeroDocumentoEmisor'],
            'numero_documento_cliente' => $documento['cabecera']['numeroDocumentoAdquiriente'],
            'razon_social_cliente' => $documento['cabecera']['razonSocialAdquiriente'],
            'fecha_captura' => now(),
        ]);
        $registro->save();

        $registro->auditoria()->create([
            'estado_anterior' => $estadoAnterior,
            'estado_nuevo' => 'CAPTURADO',
            'origen' => 'CAPTURA',
        ]);
    }

    private function marcarErrorCaptura(FeControlRegistro $registro, string $mensaje): void
    {
        $estadoAnterior = $registro->estado;
        $registro->estado = 'ERROR_CAPTURA';
        $registro->intentos_captura++;
        $registro->save();

        $registro->auditoria()->create([
            'estado_anterior' => $estadoAnterior,
            'estado_nuevo' => 'ERROR_CAPTURA',
            'origen' => 'CAPTURA',
            'detalle' => $mensaje,
        ]);

        $registro->errores()->create([
            'codigo_error' => 'ERROR_INSERCION_BIZLINKS',
            'mensaje_original' => $mensaje,
            'resuelto' => false,
        ]);
    }
}
