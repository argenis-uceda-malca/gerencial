<?php

namespace App\Services\Captura;

use App\Models\FeTienda;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;

/**
 * Aplica el mapeo de campos documentado en
 * "Mapeo de Campos - Soluflex a Bizlinks" (v1.2) para armar el arreglo
 * que InsercionBizlinksService usará para poblar SPE_EINVOICEHEADER y
 * SPE_EINVOICEDETAIL.
 *
 * PENDIENTE DE NEGOCIO (no implementado todavía, ver documento de
 * mapeo sección 7):
 *  - Pago mixto (más de una forma de pago por venta).
 *  - Tratamiento de la línea de cargo por bolsa (ICBPER) en el detalle:
 *    hoy se envía tal cual viene en DETALLE_DOCUMENTO, sin excluirla
 *    ni conciliarla contra CABECERA_DOCUMENTO.IMPORTE_ICBPER.
 */
class TransformadorDocumentoService
{
    public function transformar(ConnectionInterface $conexion, FeTienda $tienda, object $venta, Collection $detalle): array
    {
        $tipoDocumento = $this->obtenerTipoDocumentoSunat($conexion, $venta->CODIGO_DOCUMENTO);
        $emisor = $this->obtenerDatosEmisor($conexion, (int) $venta->IDEMPRESA, $tienda->idsucursal_soluflex);
        $ubicacion = $this->obtenerUbicacion($conexion, $emisor->ubigeo);
        $monedaSunat = $this->obtenerCodigoSunatMoneda($conexion, $venta->CODIGO_MONEDA);
        $cliente = $this->obtenerDatosCliente($conexion, $venta->IDPERSONA ?? null, $venta->IDENTIDAD ?? null, $venta->NOMBRE ?? null);

        $serieNumero = $this->armarSerieNumero($tipoDocumento['prefijo'], $venta->NUMERO_SERIE, $venta->NUMERO_DOCUMENTO);

        $detalleTransformado = $detalle->map(function ($item) use ($conexion, $tipoDocumento, $serieNumero, $emisor) {
            $cantidad = (float) $item->CANTIDAD;
            $cantidad = $cantidad !== 0.0 ? $cantidad : 1.0; // salvaguarda ante división por cero

            return [
                'tipoDocumentoEmisor' => '6',
                'numeroDocumentoEmisor' => $emisor->ruc,
                'tipoDocumento' => $tipoDocumento['codigoSunat'],
                'serieNumero' => $serieNumero,
                'numeroOrdenItem' => (int) $item->SECUENCIA,
                'cantidad' => $cantidad,
                'unidadMedida' => $this->obtenerUnidadMedidaSunat($conexion, $item->CODIGO_UNIMED ?? null),
                'codigoProducto' => $item->CODIGO_PRODUCTO,
                'descripcion' => $this->obtenerDescripcionProducto($conexion, $item->CODIGO_PRODUCTO),
                // Confirmado con venta real (IDTRANSACCION 262941): estos
                // campos vienen netos de descuento, sin usar PRECIO_UNITARIO
                // ni PRECIO_UNITARIO_REAL (precio de lista antes de dscto.).
                'importeUnitarioSinImpuesto' => round(((float) $item->IMPORTE_SUBTOTAL) / $cantidad, 2),
                'importeUnitarioConImpuesto' => round(((float) $item->IMPORTE_TOTAL) / $cantidad, 2),
                'codigoImporteUnitarioConImpuesto' => '01',
                'totalMontoICBPER' => (float) ($item->IMPORTE_ICBPER ?? 0),
                // Campo de uso interno, no se envía a Bizlinks; se usa
                // para la validación de reconciliación de totales y se
                // descarta en InsercionBizlinksService.
                'importeTotalItem' => (float) $item->IMPORTE_TOTAL,
            ];
        })->values()->all();

        $sumaDetalleTotal = array_sum(array_column($detalleTransformado, 'importeTotalItem'));
        $montoRedondeo = round(((float) $venta->IMPORTE_TOTAL) - $sumaDetalleTotal, 2);

        $cabecera = [
            'serieNumero' => $serieNumero,
            'fechaEmision' => Carbon::parse($venta->FECHA_DOCUMENTO)->format('Ymd'),
            'tipoDocumento' => $tipoDocumento['codigoSunat'],
            'tipoMoneda' => $monedaSunat,
            'numeroDocumentoEmisor' => $emisor->ruc,
            'tipoDocumentoEmisor' => '6',
            'nombreComercialEmisor' => $emisor->nombreTienda,
            'razonSocialEmisor' => $emisor->razonSocial,
            'ubigeoEmisor' => $emisor->ubigeo,
            'direccionEmisor' => $emisor->direccion,
            'provinciaEmisor' => $ubicacion['provincia'],
            'departamentoEmisor' => $ubicacion['departamento'],
            'distritoEmisor' => $ubicacion['distrito'],
            'paisEmisor' => 'PE',
            // correoEmisor deliberadamente omitido: es configuración del
            // propio portal de Bizlinks, no responsabilidad de este motor
            // (confirmado en el documento de integración).
            'codigoLocalAnexoEmisor' => $emisor->codigoAnexo,
            'tipoDocumentoAdquiriente' => $cliente['tipoDocumentoSunat'],
            'numeroDocumentoAdquiriente' => $cliente['numeroDocumento'],
            'razonSocialAdquiriente' => $cliente['razonSocial'],
            'correoAdquiriente' => $cliente['correo'],
            'totalImpuestos' => (float) $venta->IMPORTE_IGV,
            'totalValorVentaNetoOpGravadas' => (float) $venta->IMPORTE_SUBTOTAL,
            'totalIgv' => (float) $venta->IMPORTE_IGV,
            'totalVenta' => (float) $venta->IMPORTE_TOTAL,
            'totalValorVenta' => (float) $venta->IMPORTE_SUBTOTAL,
            'totalPrecioVenta' => (float) $venta->IMPORTE_TOTAL,
            'montoRedondeoTotalVenta' => $montoRedondeo,
            'totalMontoICBPER' => (float) ($venta->IMPORTE_ICBPER ?? 0),
            'bl_estadoRegistro' => 'A',
            'bl_origen' => 'T',
            'bl_reintento' => 0,
        ];

        return ['cabecera' => $cabecera, 'detalle' => $detalleTransformado];
    }

    private function armarSerieNumero(string $prefijo, $numeroSerie, $numeroDocumento): string
    {
        // Formato fijo confirmado en el documento de integración:
        // F###-NNNNNNNN / B###-NNNNNNNN (3 dígitos de serie + 8 de número).
        return sprintf('%s%03d-%08d', $prefijo, (int) $numeroSerie, (int) $numeroDocumento);
    }

    private function obtenerTipoDocumentoSunat(ConnectionInterface $conexion, string $codigoDocumento): array
    {
        $doc = $conexion->selectOne('SELECT CODIGO_SUNAT FROM DOCUMENTOS WHERE CODIGO_DOCUMENTO = ?', [$codigoDocumento]);
        $codigoSunat = $doc->CODIGO_SUNAT ?? null;

        return [
            'codigoSunat' => $codigoSunat,
            'prefijo' => $codigoSunat === '01' ? 'F' : 'B', // Factura=F, Boleta (y demás electrónicos)=B
        ];
    }

    private function obtenerDatosEmisor(ConnectionInterface $conexion, int $idEmpresa, ?int $idSucursal): object
    {
        $empresa = $conexion->selectOne('SELECT RUC, EMPRESA, DIRECCION FROM EMPRESAS WHERE IDEMPRESA = ?', [$idEmpresa]);

        $sucursal = $idSucursal
            ? $conexion->selectOne('SELECT NOMBRE_TIENDA, DIRECCION1, CODIGO_ANEXO FROM M_SUCURSALES WHERE IDSUCURSAL = ?', [$idSucursal])
            : null;

        $ubicacion = $idSucursal
            ? $conexion->selectOne('SELECT UBIGEO FROM M_SUCURSALES_UBICACION WHERE IDSUCURSAL = ?', [$idSucursal])
            : null;

        return (object) [
            'ruc' => $empresa->RUC ?? null,
            'razonSocial' => $empresa->EMPRESA ?? null,
            'direccion' => $sucursal->DIRECCION1 ?? ($empresa->DIRECCION ?? null),
            'nombreTienda' => $sucursal->NOMBRE_TIENDA ?? null,
            'codigoAnexo' => $sucursal->CODIGO_ANEXO ?? null,
            'ubigeo' => $ubicacion->UBIGEO ?? null,
        ];
    }

    private function obtenerUbicacion(ConnectionInterface $conexion, ?string $ubigeo): array
    {
        if (! $ubigeo) {
            return ['departamento' => null, 'provincia' => null, 'distrito' => null];
        }

        $departamento = substr($ubigeo, 0, 2).'0000';
        $provincia = substr($ubigeo, 0, 4).'00';

        $filas = $conexion->select('
            SELECT TIPO_UBIGEO, UBICACION_GEOGRAFICA
            FROM M_UBICACION_GEOGRAFICA
            WHERE CODIGO_UBIGEO_REAL IN (?, ?, ?)
              AND CODIGO_PAIS = 167
        ', [$ubigeo, $provincia, $departamento]);

        $porTipo = collect($filas)->keyBy('TIPO_UBIGEO');

        return [
            'distrito' => $porTipo[3]->UBICACION_GEOGRAFICA ?? null,
            'provincia' => $porTipo[2]->UBICACION_GEOGRAFICA ?? null,
            'departamento' => $porTipo[1]->UBICACION_GEOGRAFICA ?? null,
        ];
    }

    private function obtenerCodigoSunatMoneda(ConnectionInterface $conexion, string $codigoMoneda): ?string
    {
        $fila = $conexion->selectOne('SELECT codigo_sunat FROM M_MONEDA WHERE codigo_moneda = ?', [$codigoMoneda]);

        return $fila->codigo_sunat ?? null;
    }

    private function obtenerUnidadMedidaSunat(ConnectionInterface $conexion, ?string $codigoUnimed): string
    {
        if (! $codigoUnimed) {
            return 'NIU';
        }

        $fila = $conexion->selectOne('SELECT CODIGO_SUNAT FROM M_UNIDADMEDIDA WHERE CODIGO_UNIMED = ?', [$codigoUnimed]);

        return $fila->CODIGO_SUNAT ?? 'NIU';
    }

    private function obtenerDescripcionProducto(ConnectionInterface $conexion, string $codigoProducto): ?string
    {
        $fila = $conexion->selectOne('SELECT PRODUCTO FROM PRODUCTOS WHERE CODIGO_PRODUCTO = ?', [$codigoProducto]);

        return $fila->PRODUCTO ?? null;
    }

    /**
     * Resuelve tipo/número de documento y datos de contacto del cliente
     * vía M_PERSONAS (fuente confirmada con datos reales — el campo
     * TIPO_AUXILIAR de CABECERA_DOCUMENTO se descartó, no corresponde
     * al documento de identidad del cliente).
     */
    private function obtenerDatosCliente(ConnectionInterface $conexion, ?int $idPersona, ?string $identidadFallback, ?string $nombreFallback): array
    {
        if ($idPersona) {
            $persona = $conexion->selectOne('
                SELECT p.NUMERO_IDENTIDAD, p.PERSONA, p.EMAIL1, t.CODIGO_SUNAT
                FROM M_PERSONAS p
                LEFT JOIN M_TIPO_IDENTIDAD t ON t.TIPO_IDENTIDAD = p.TIPO_IDENTIDAD
                WHERE p.IDPERSONA = ?
            ', [$idPersona]);

            if ($persona) {
                return [
                    'tipoDocumentoSunat' => $persona->CODIGO_SUNAT,
                    'numeroDocumento' => $persona->NUMERO_IDENTIDAD,
                    'razonSocial' => $persona->PERSONA,
                    'correo' => $persona->EMAIL1,
                ];
            }
        }

        // Sin IDPERSONA resoluble: se usa lo que ya viene en la cabecera
        // como respaldo. tipoDocumentoSunat queda nulo a propósito, para
        // que ValidadorCapturaService lo detecte como CLIENTE_SIN_DOCUMENTO.
        return [
            'tipoDocumentoSunat' => null,
            'numeroDocumento' => $identidadFallback,
            'razonSocial' => $nombreFallback,
            'correo' => null,
        ];
    }
}
