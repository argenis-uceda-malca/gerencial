<?php

return [
    // Destinatario por defecto de alertas técnicas (ALERTA_SOLO en
    // FE_REGLAS_VALIDACION_CAPTURA, errores técnicos del Motor, etc.)
    'correo_alertas' => env('CAPTURA_CORREO_ALERTAS', 'soporte@tuempresa.com'),
];
