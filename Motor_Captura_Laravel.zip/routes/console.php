<?php

use Illuminate\Support\Facades\Schedule;

/*
|--------------------------------------------------------------------------
| Programación del Motor de Captura
|--------------------------------------------------------------------------
| Un único cron del servidor ejecuta "* * * * * php artisan schedule:run".
| withoutOverlapping() evita que arranque una segunda ejecución si la
| anterior sigue corriendo (ej. una tienda con conexión lenta).
|
| El intervalo real de negocio (ej. cada 90 segundos) se controla desde
| FE_CONFIGURACION.INTERVALO_CAPTURA_SEGUNDOS: el propio Command puede
| comparar la última corrida contra ese valor y decidir si le toca
| ejecutar el ciclo completo o solo salir, sin tocar este archivo.
|
| Si este proyecto usa Laravel 10 o anterior (con app/Console/Kernel.php),
| mueve este bloque al método schedule() de esa clase en vez de aquí.
*/
Schedule::command('captura:ejecutar')
    ->everyMinute()
    ->withoutOverlapping()
    ->runInBackground();
